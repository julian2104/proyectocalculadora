package guia1;

public class Calculadora {

    public float num1, num2,costoproduc, porceniva, result;

    public void suma() {
        result = num1 + num2;
    }

    public void resta() {
        result = num1 - num2;
    }

    public void mult() {
        result = num1 * num2;
    }

    public void div() {
        result = num1 / num2;
    }

    public void sen(double b) {
        result = (float) Math.sin(b);
    }

    public void tan(double b) {
        result = (float) Math.tan(b);
    }

    public void cos(double b) {
        result = (float) Math.cos(b);
    }

    public void raiz(double a, double b) {
        result = (float) Math.pow(b,1/a);
    }

    public void pot(double a, double b) {
        result = (float) Math.pow(a,b);
    }

    public void iva() {
        result = costoproduc * (porceniva/100);
    }

}
