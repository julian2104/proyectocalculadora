
package guia1;

import java.util.Scanner;


public class Consola {
    
    public static void main(String[] args) {
       Scanner ingreso = new Scanner(System.in);
       Calculadora calcu1 = new Calculadora();
       
       System.out.print("Ingrese el numero 1: \n");
       float a=ingreso.nextFloat();
       System.out.print("Ingrese el numero 2: \n");
       float b=ingreso.nextFloat();
       calcu1.num1=a;
       calcu1.num2=b;
       calcu1.suma();
       System.out.println("La suma de los numeros es: "+calcu1.result);
       calcu1.resta();
       System.out.println("La resta de los numeros es:"+calcu1.result);
       calcu1.mult();
       System.out.println("La multiplicacion entre los numeros es:"+calcu1.result);
       calcu1.div();
       System.out.println("la division entre los numeros es"+calcu1.result);
       calcu1.cos(b);
       System.out.println("El coseno del numero es:"+calcu1.result);
       calcu1.sen(b);
       System.out.println("El seno del numero es:"+calcu1.result);
       calcu1.tan(b);
       System.out.println("la tangente del numero es:"+calcu1.result);
       calcu1.raiz(b,a);
       System.out.println("La raiz enesima del numero es:"+calcu1.result);
       calcu1.pot(a,b);
       System.out.println("La potencia del numero es:"+calcu1.result);
       System.out.println("Ingrese el costo de un producto");
       float d=ingreso.nextFloat();
       calcu1.costoproduc=d;
       System.out.println("Ingrese el valor del iva");
       float e=ingreso.nextFloat();
       calcu1.porceniva=e;
       calcu1.iva();
       System.out.println("El iva de los numeros ingresados es:"+calcu1.result);
    }
    
}
